package com.example.angierincon.ejerciciograbar;

import java.io.File;
import java.io.IOException;

import android.app.Activity;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;
import android.view.MenuItem;


public class MainGrabar extends Activity implements OnCompletionListener {

    TextView tv1, tv2, tv3;
    MediaRecorder recorder = new MediaRecorder();
    MediaPlayer player = new MediaPlayer();
    File archivo;
    Button grabar, parar, reproducir;
    EditText nom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_grabar);

        nom = (EditText) findViewById(R.id.editText);
        tv1 = (TextView) this.findViewById(R.id.tv1);
        tv2 = (TextView) this.findViewById(R.id.tv2);
        tv3 = (TextView) this.findViewById(R.id.tv3);
        grabar = (Button) findViewById(R.id.Grabar);
        parar = (Button) findViewById(R.id.Parar);
        reproducir = (Button) findViewById(R.id.Reproducir);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main_grabar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void grabar(View v) {
        String nombre = nom.getText().toString();
        if (nombre.length() == 0) { // hace la comparacion a ver si la casilla de nombre esta vacio o no
            Toast notificacion = Toast.makeText(this, "No ha ingresado el nombre del archivo", Toast.LENGTH_LONG);
            notificacion.show();
        } else if (nombre.length() != 0) {
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC); //definicion de microfono como fuente
            recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);//como se guarda el archivo
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);//especificamos el code
            //Obtiene el path de la tarjeta SD y crea un archivo temporal con extensión .3pg
            File path = new File(Environment.getExternalStorageDirectory().getPath());
            try {
                archivo = File.createTempFile(nombre, ".3gp", path);
            } catch (IOException e) {
            }
            //le dice donde alamacenar la grabación
            recorder.setOutputFile(archivo.getAbsolutePath());
            // metodo para empezar la grabación
            try {
                recorder.prepare();
            } catch (IOException e) {
            }
            recorder.start();
            tv3.setText("Grabando...");
            grabar.setEnabled(false);
            parar.setEnabled(true);
        }
    }

    public void parar(View v) {
        // se detiene la grabación
        recorder.stop();
        recorder.release();
        //creamos un objeto para que se pueda reproducir lo grabado
        player.setOnCompletionListener(this);
        //Le decimos en donde lo podemos reproducr
        try{
            player.setDataSource(archivo.getAbsolutePath());
        }catch(IOException e){
        }
        //Llamamos el metodo prepare de la clase mediaplayer
        try{
            player.prepare();
        }catch (IOException e){
        }
        //
        grabar.setEnabled(true);
        parar.setEnabled(false);
        reproducir.setEnabled(true);
        tv3.setText("La grabación fue un exito, Reproduscala");

    }

    public void reproducir(View v) {
        //empieza la reproducir
        player.start();
        grabar.setEnabled(false);
        parar.setEnabled(false);
        reproducir.setEnabled(false);
        tv3.setText("Reproduciendo...");
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        grabar.setEnabled(true);
        parar.setEnabled(true);
        reproducir.setEnabled(true);
        tv3.setText("Listo Ome");
    }
}
